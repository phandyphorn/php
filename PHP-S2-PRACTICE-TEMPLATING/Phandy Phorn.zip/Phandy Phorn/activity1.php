before php tag
<?php
    // Just execute this file and understand What happens if there is text outside of php tags ?
    
    // Outsite php just copy, but whatever in php it will execute and then show.
    echo "Inside first php tag";
    $a=0;
?>

between php tags

<?php 
   $a +=1;
?>


<?php 
    echo $a;

?>

after php tag




