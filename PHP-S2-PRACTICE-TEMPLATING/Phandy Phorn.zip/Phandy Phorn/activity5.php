
<ul>
    <?php
    // Instructions: replace XXXXXXXXX by a code to display the value of $index from 0 to 4
    for ($index = 0; $index < 5; $index++) :
    ?>
        <li><?php echo "current index is ".$index?></li>
    <?php
    endfor
    ?>
</ul>